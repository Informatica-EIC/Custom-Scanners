#!/bin/bash

propfile=$1
# call the model linker 

java -cp "athenaScan.jar:lib/*" com.informatica.edc.custom.AthenaScanner ${propfile}


zip athena_edc_custom.zip athenaObjects.csv athenaTablesViews.csv athenaColumns.csv links.csv

#complete
echo 'Finished'
