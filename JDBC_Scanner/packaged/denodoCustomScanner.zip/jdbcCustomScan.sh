java -cp "customJdbcScanner.jar:lib/*" com.infa.edc.scanner.jdbc.GenericScanner $1
pause
